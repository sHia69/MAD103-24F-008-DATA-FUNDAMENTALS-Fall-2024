-- Create a table that will hold the following information
-- I want to store some student's first names and last names and their favourite courses:
-- First Name: Mark
-- Last Name: Hamil
-- Favourite Course: MAD 102

-- First Name: Kevin
-- Last Name: Conroy
-- Favourite Course: MAD 103

-- First Name: Mark
-- Last Name: Conroy
-- Favourite Course: MAD 103
-- Enter your answer here:



-- We want to add a new column to the table which will hold a code that shows their graduation date - for example if they graduate in teh spring of 2022 it would hold S22.  If in the fall, it would be F22.  Add this column to the table - we will not know when the student graduates until a year or so after they start.
-- Enter your answer here:



-- Insert the information into the table
-- Enter your answer here:



-- Mark Conroy has decided that his favourite course is Java - enter MAD 101 as the favourite course (it could happen! :) )
-- Enter your answer here:




-- Mark Conroy has decided to withdraw from the program - please remove him from the table
-- Enter your answer here:



-- Remove all remaining records from the table - but keep the table itself
-- Enter your answer here:




-- Remove the table
-- Enter your answer here:



-- Using the products table answer the following questions:
-- Show me all the products where the code ends with a 9



--Show me all the products that start with S12 


-- Show me all the Vintage cars



-- show me all the products where the scale is 1:10



-- show me all the products where the vendor has 66 in the name



-- showme all the products that are related to Harley Davidson


-- show me all the motorocycles


-- show me all the products where we have between 1000 and 2000 in stock


-- show me all the products I can buy with the $75 I have


-- show me all the products that cost more than I can afford - I only have $100


-- Show me the vintage cards from the vendor motor city art classics


-- show me all the all the trucks and buses, planes and motorcycles.  Place them in alphabetical order by vendor name



-- show me all the products in order of MSRP


-- show me all our vendors - do not repeat them


-- show all the products that have opening hoods (Hint - take a peek at the product descriptions)



