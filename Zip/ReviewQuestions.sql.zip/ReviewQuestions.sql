-- What is the average reorder level?


-- How many discontinued products do we sell


-- How many suppliers do we have in each country - order from most to least?


-- What product category do have the most units in stock?


-- What products com from Germany?


-- What is the full name of the employee and their birthday, that packed the order #10257


-- What are the categories of products that people in Sweden buy - show only unique product names


-- Show me the suppliers, their products and the product category and group 


-- show me the products that each company ordered, and what company shipped them - show the results in alphabetical order by company name



